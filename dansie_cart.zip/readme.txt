Dansie Shopping Cart
Credit Card Processing Configuration File Setup
Last Updated: 10/25/02

Overview of Usage:

The Dansie Shopping Cart will calculate the order's total amount, collect the customer's shipping & billing addresses, and then will pass the order's total, billing address and a couple other parameters to our secure servers.  Our payment gateway will collect the customer's credit card number, expiration date & other information on our server's secure billing pages.  When the customer has submitted their credit card and billing information, we approve the customer's credit card & redirect the customer back to the "Approved Return URL" that the Dansie Shopping Cart automatically passed to us.  If the credit card is denied, we will redirect the customer back to a "Disapproved Return URL" that the cart automatically passes to us. At this Disapproved URL, the shopping cart will provide other methods of payment to the customer.

If you would like to use the Dansie Shopping Cart to work with our real-time payment gateway services, you need to edit & then publish the "processor.dat" file to the same directory as your "vars.dat" file on your web server.  The enclosed "processor.dat" file works with Dansie Shopping Cart v2.88 & newer.

In order to setup this file to match your account, you need to do the following:

--- Open the processor.dat file in a text editor (such as Notepad).
--- Replace all instances of 'xxxMERCHANTxxx' in the file with your account login username.

    For example, if your username is "pnpdemo", then variable #4 would look like below:

    4 Login ID -->pnpdemo

--- Next update variable #22.  This variable states which credit cards you can accept online.  Simply remove those credit cards you do not have a merchant account for & cannot accept online.

    For example, if you can only accept Visa, Mastercard & American Express cards, the line would like this:

    22 Custom3 -->card-allowed|Visa,Mastercard,Amex

--- If you do not want us to ask for shipping information, change the 'shipinfo' variable from "1" to "0".
--- When you are done, save the changes & exit your text editor.
--- FTP the updated "processor.dat" file to the same directory as your "vars.dat" file on your web server.

